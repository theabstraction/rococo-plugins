#ifdef _WIN32
# pragma warning(default: 4456)
# pragma warning(default: 4459)
# pragma warning(default: 4996)
# pragma warning(default: 4611)
#else
#endif