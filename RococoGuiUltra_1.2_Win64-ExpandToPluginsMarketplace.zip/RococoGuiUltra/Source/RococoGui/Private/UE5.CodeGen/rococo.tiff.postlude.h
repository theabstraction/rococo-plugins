#ifdef _WIN32
# pragma warning(default: 4456)
# pragma warning(default: 4459)
# pragma warning(default: 4996)
# undef _CRT_SECURE_NO_WARNINGS 
#else
#endif