// Copyright (c)2025 Mark Anthony Taylor (mark.anthony.taylor@gmail.com). All rights reserved.
// This software is open source, but not free. Check the rococo master branch for the latest Copyright rules that applies to this software

#ifdef _WIN32
# pragma warning(disable: 4456)
#else
#endif