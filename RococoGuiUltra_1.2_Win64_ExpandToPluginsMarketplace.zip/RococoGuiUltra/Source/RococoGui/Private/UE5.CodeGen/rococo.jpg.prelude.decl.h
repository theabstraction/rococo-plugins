#pragma once
#include "rococo.jpg.prelude.h"
#include "rococo.jpeg.decl.h"
