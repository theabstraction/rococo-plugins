#ifdef _WIN32
# pragma warning(disable: 4456)
# pragma warning(disable: 4459)
# pragma warning(disable: 4996)
#else
#endif