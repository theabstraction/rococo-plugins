#ifdef _WIN32
# pragma warning(default: 4458)
# pragma warning(default: 4265)
#else
# pragma clang diagnostic pop
#endif
